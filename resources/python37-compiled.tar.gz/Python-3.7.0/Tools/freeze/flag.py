initialized = True
print("Hello world!")
