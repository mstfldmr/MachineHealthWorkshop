#
# REPLACE THE WHOLE CODE
# WITH THE CODE OF THE
# ML INFERENCE LAMBDA
#
from __future__ import print_function

print('Loading function')

def lambda_handler(event, context):
    print("event: {}".format(event))
    return {"message": "i love greegrass"}
